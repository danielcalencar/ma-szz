CREATE TABLE szz_project_lastrevisionprocessed (
  project character varying, -- project from apache
  lastrevisionprocessed bigint -- last revision that was processed by the project
)
WITH (
  OIDS=FALSE
);


CREATE TABLE bugintroducingcode
(
  linenumber bigint,
  path character varying,
  content character varying,
  revision bigint,
  fixrevision bigint,
  project character varying,
  szz_date timestamp without time zone,
  copypath character varying,
  copyrevision bigint,
  mergerev boolean,
  branchrev boolean,
  changeproperty boolean,
  missed boolean,
  furtherback boolean,
  wrong boolean

)
WITH (
  OIDS=FALSE
);
